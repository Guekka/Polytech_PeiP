## 1.2

> Identifiez les boîtes qui devront changer de style d'affichage pour parvenir à la nouvelle architecture;
> Précisez/expliquez quelles modifications ces boîtes doivent subir. Ne donnez
> aucun code pour répondre à cet exercice

Les boîtes qui doivent changer sont les colonnes de contenu et la colonne
Twitter

Les colonnes seront linéarisées et mises à la suite.
La colonne Twitter occupera plus de place horizontale.

## 2.2

> Même question

La colonne Twitter sera linéarisée et mise à la suite du contenu.
Le menu sera caché et affiché par hover, il est affiché en lignes et non plus en
colonnes. Sa taille sera adaptée
